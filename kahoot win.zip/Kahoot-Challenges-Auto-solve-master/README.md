<h1 align="center">Welcome to Kahoot-Challenges-Auto-solve 👋</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.3-blue.svg?cacheSeconds=2592000" />
  <a href="#" target="_blank">
    <img alt="License: MIT" src="https://img.shields.io/badge/License-MIT-yellow.svg" />
  </a>
</p>

> A kahoot challenge hack with auto-solve support that runs in the browser

### 🏠 [Homepage](https://discord.gg/bEzfrQ4)

## Author

👤 **Element21 && East_Arctica**

* Github: [@Element21](https://github.com/Element21)
* Github: [@East_Arctica](https://github.com/East_Arctica)

## Show your support

Give a ⭐️ if this project helped you!

***
_This README was generated with ❤️ by [readme-md-generator](https://github.com/kefranabg/readme-md-generator)_
